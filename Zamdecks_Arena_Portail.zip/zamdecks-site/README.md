# Zamdecks Arena — portail officiel (base initiale)

## Contenu
- `index.html` : page d'accueil du portail
- `jeu/index.html` : copie intégrale du jeu Zamdecks Arena V1.2 (fichier source conservé)
- `wiki/` : accueil du Wiki et rubriques Héros, Zamdecks, Attaques, Traits
- `regles/` : plan du guide des règles et mécaniques
- `actualites/` : journal des annonces
- `assets/` : styles et navigation commune

## Tester en local
Ouvrir `index.html` dans un navigateur. Pour un test plus fidèle, servir le dossier avec un serveur HTTP local.

## Publier gratuitement avec GitHub Pages
1. Créer un compte sur https://github.com/ puis un dépôt public nommé `zamdecks-arena`.
2. Envoyer le contenu de ce dossier à la racine du dépôt (pas le dossier parent lui-même).
3. Dans le dépôt : **Settings → Pages**.
4. Dans **Build and deployment**, choisir **Deploy from a branch**, branche `main`, dossier `/ (root)`, puis **Save**.
5. Attendre la publication. L'adresse sera de la forme `https://VOTRE-PSEUDO.github.io/zamdecks-arena/`.

## À savoir
- GitHub Pages héberge des fichiers statiques : HTML, CSS, JavaScript et images.
- Le jeu existant est inclus sans réécriture. Ses données enregistrées dans `localStorage` restent propres au navigateur et à l'appareil.
- Le Wiki est une structure éditoriale initiale : les fiches réelles doivent être alimentées avec les données canoniques du projet. Rien n'a été inventé pour remplir les rubriques.
- Pour les mises à jour, modifier les fichiers puis envoyer les changements sur la branche `main`.
- Un nom de domaine personnalisé est facultatif et peut être ajouté ultérieurement.
