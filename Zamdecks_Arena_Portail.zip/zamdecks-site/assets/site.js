const menu=document.querySelector('.menu');if(menu)menu.addEventListener('click',()=>document.querySelector('.links').classList.toggle('open'));
